#include <stdio.h>
#include "stdint.h"
#include "stm32f4xx.h"
#include "uart.h"
#include <cstdlib>

#include <math.h>
#include "tensorflow/lite/experimental/micro/kernels/all_ops_resolver.h"
#include "tensorflow/lite/experimental/micro/micro_error_reporter.h"
#include "tensorflow/lite/experimental/micro/micro_interpreter.h"
#include "sine_model_data.h"

#define GPIOAEN						(1U<<0)
#define GPIOA_5						(1U<<5)
#define LED_PIN						GPIOA_5

float key;


// Create a memory pool for the nodes in the network
constexpr int tensor_pool_size = 2 * 1024;
uint8_t tensor_pool[tensor_pool_size];

// Define the model to be used
const tflite::Model* sine_model;

// Define the interpreter
tflite::MicroInterpreter* interpreter;

// Input/Output nodes for the network
TfLiteTensor* input;
TfLiteTensor* output;

int main(void){
	uart2_rxtx_init();

	printf("Loading Tensorflow model....\n\r");
	sine_model = tflite::GetModel(g_sine_model_data);
	printf("Sine model loaded!\n\r");

	// Define ops resolver and error reporting
	static tflite::ops::micro::AllOpsResolver resolver;

	static tflite::ErrorReporter* error_reporter;
	static tflite::MicroErrorReporter micro_error;
	error_reporter = &micro_error;

	// Instantiate the interpreter 
	static tflite::MicroInterpreter static_interpreter(
		sine_model, resolver, tensor_pool, tensor_pool_size, error_reporter
	);

	interpreter = &static_interpreter;

	// Allocate the the model's tensors in the memory pool that was created.
	printf("Allocating tensors to memory pool\n\r");
	if(interpreter->AllocateTensors() != kTfLiteOk) {
		printf("There was an error allocating the memory...ooof\n\r");
		return 0;
	}

	// Define input and output nodes
	input = interpreter->input(0);
	output = interpreter->output(0);
	printf("Starting inferences... Input a number! \n\r");
			

	while (1) {
        char buffer[3]; // Assuming the input won't exceed 64 characters
		int index = 0;
		if(uart2_available() > 0){


			// Read characters until newline is received
			while (1) {
				char ch = uart2_read();
				printf("Received character: %c (ASCII: %d)\n\r", ch, ch);
				
				if (ch == '\r' || ch == '\n') {
					buffer[index] = '\0';
					break;
				}
				buffer[index++] = ch;
			}

			// Convert ASCII input to float
			
			float user_input = buffer[0] - '0';
			buffer[0]=0;
			if(user_input < 0.0f || user_input > (float)(2*M_PI)) {
				printf("\n\rYour number must be greater than 0 and less than 2*PI\n\r");
				//return 0;
			}
    	
    	// Set the input node to the user input
    		input->data.f[0] = user_input;

    		printf("Running inference on inputted data...\n\r");

    	// Run inference on the input data
    		if(interpreter->Invoke() != kTfLiteOk) {
    			printf("There was an error invoking the interpreter!\n\r");
    			//return;
    		}

    	// Print the output of the model.
    		printf("Input: ");
			printf("%f \n\r",user_input);
    	
			printf("Output: ");
    	
			printf("%f \n\r",output->data.f[0]);
    		printf("\n\r");
		}

	}

}
