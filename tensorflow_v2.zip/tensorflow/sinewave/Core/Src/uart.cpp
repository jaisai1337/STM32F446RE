#include <stdio.h>
#include <string.h>
#include "uart.h"

static void uart_set_baudrate(USART_TypeDef *USARTx, uint32_t PeriphClk, uint32_t BaudRate);
static uint16_t compute_uart_bd(uint32_t PeriphClk, uint32_t BaudRate);

// Initialize UART2 for both transmission and reception
void uart2_txrx_init(void){
    // Enable clock access to GPIOA
    RCC->AHB1ENR |= GPIOAEN;

    // Set PA2 mode to alternate function mode (UART_TX)
    GPIOA->MODER &= ~(1U << 4);
    GPIOA->MODER |= (1U << 5);
    // Set PA2 alternate function type to UART_TX (AF07)
    GPIOA->AFR[0] |= (1U << 8) | (1U << 9) | (1U << 10);
    GPIOA->AFR[0] &= ~(1U << 11);

    // Set PA3 mode to alternate function mode (UART_RX)
    GPIOA->MODER &= ~(1U << 6);
    GPIOA->MODER |= (1U << 7);
    // Set PA3 alternate function type to UART_RX (AF07)
    GPIOA->AFR[0] |= (1U << 12) | (1U << 13) | (1U << 14);
    GPIOA->AFR[0] &= ~(1U << 15);

    // Enable clock access to UART2
    RCC->APB1ENR |= UART2EN;
    // Configure the baud rate
    uart_set_baudrate(USART2, APB1_CLK, BAUDRATE);
    // Enable UART for both transmission and reception
    USART2->CR1 |= CR1_TE | CR1_RE;
    // Enable the UART module
    USART2->CR1 |= CR1_UE;
}

// Initialize UART2 for transmission
void uart2_tx_init(void){
    // Enable clock access to GPIOA
    RCC->AHB1ENR |= GPIOAEN;
    // Set PA2 mode to alternate function mode (UART_TX)
    GPIOA->MODER &= ~(1U << 4);
    GPIOA->MODER |= (1U << 5);
    // Set PA2 alternate function type to UART_TX (AF07)
    GPIOA->AFR[0] |= (1U << 8) | (1U << 9) | (1U << 10);
    GPIOA->AFR[0] &= ~(1U << 11);
    // Enable clock access to UART2
    RCC->APB1ENR |= UART2EN;
    // Configure the baud rate
    uart_set_baudrate(USART2, APB1_CLK, BAUDRATE);
    // Configure the transfer direction (transmit only)
    USART2->CR1 |= CR1_TE;
    // Enable the UART module
    USART2->CR1 |= CR1_UE;
}

// Write a character to UART
void uart2_write(int ch){
    // Wait until the transmit data register is empty
    while (!(USART2->SR & SR_TXE));
    // Write to the transmit data register
    USART2->DR = (ch & 0xFF);
}

// Read a character from UART
char uart2_read(void){
    // Wait until the receive data register is not empty
    while (!(USART2->SR & SR_RXNE));
    // Return the received data
    return USART2->DR;
}

// Read a string from UART into buffer
void uart2_read_string(char *buffer, uint8_t length){
    for (uint8_t i = 0; i < length; i++) {
        buffer[i] = uart2_read();
        // Break on newline or carriage return
        if (buffer[i] == '\n' || buffer[i] == '\r') {
            buffer[i] = '\0';
            break;
        }
    }
    buffer[length - 1] = '\0';  // Ensure null termination
}
bool uart2_available(void){
	// Make sure that the receive data register is not empty
	while (!(USART2->SR & SR_RXNE));
	return true;
}
#define BUFFER_SIZE 100

// Function to read a float from UART input
float uart2_read_float(void) {
    char buffer[BUFFER_SIZE];
    float value;
    while (1) {
        // Read a string from UART
        uart2_read_string(buffer, BUFFER_SIZE);
        // Try to parse the float from the string
        if (sscanf(buffer, "%f", &value) == 1) {
            return value;
        } else {
            // If parsing fails, prompt the user again
            printf("Invalid input. Please enter a valid float number:\n\r");
        }
    }
}

// Set the baud rate for UART
static void uart_set_baudrate(USART_TypeDef *USARTx, uint32_t PeriphClk, uint32_t BaudRate){
    USARTx->BRR = compute_uart_bd(PeriphClk, BaudRate);
}

// Compute the UART baud rate value
static uint16_t compute_uart_bd(uint32_t PeriphClk, uint32_t BaudRate){
    return ((PeriphClk + (BaudRate / 2U)) / BaudRate);
}