#ifndef UART_H
#define UART_H

#include "stm32f4xx.h"
#include "stdint.h"

// Macros for UART
#define GPIOAEN                     (1U<<0)
#define UART2EN                     (1U<<17)
#define CR1_TE                      (1U<<3)
#define CR1_RE                      (1U<<2)
#define CR1_UE                      (1U<<13)
#define SR_TXE                      (1U<<7)
#define SR_RXNE                     (1U<<5)
#define SYS_FREQ                    16000000
#define APB1_CLK                    SYS_FREQ
#define BAUDRATE                    115200

// UART initialization functions
void uart2_txrx_init(void);
void uart2_tx_init(void);

// UART transmission functions
void uart2_write(int ch);

// UART reception functions
char uart2_read(void);
void uart2_read_string(char *buffer, uint8_t length);

// Function to read a float from UART
float uart2_read_float(void);
bool uart2_available(void);

#endif // UART_H